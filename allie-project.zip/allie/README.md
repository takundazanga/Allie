# Allie — Taku's Workspace Partner

> A personal AI workspace built for Takunda Zanga. Not a generic tool — a context-aware thinking partner that carries full knowledge of every project, every creative thread, and the A³I philosophy that connects them.

---

## What This Is

Allie is a single-file HTML app powered by the Anthropic Claude API. It has two core surfaces:

- **Home** — a conversation interface where Allie acts as a thinking partner, writer, challenger, editor, or build partner depending on which mode you're in
- **Skills Lab** — a contextual learning layer where each skill is taught in direct relation to what you're actually building, not as a generic curriculum

The key design principle: **Allie knows who Taku is from the first word**. The system prompt carries full context — all projects, all creative work, the A³I philosophy, the editorial methodology, the ghost mentor framework. No onboarding required.

---

## Project Structure

```
allie/
├── index.html        ← The entire app (HTML + CSS + JS in one file)
├── vercel.json       ← Vercel static deployment config
├── README.md         ← This file
└── CLAUDE.md         ← Instructions for Claude Code (see below)
```

---

## Running Locally

Just open `index.html` in a browser. That's it.

Inside **claude.ai**, the Anthropic API is proxied automatically — no key needed.

Outside claude.ai (local browser or after Vercel deploy), you need to add your key:

1. Open `index.html`
2. Find this comment near the top of the `<script>` block:
   ```js
   // const API_KEY = 'sk-ant-...';
   ```
3. Uncomment it, paste your key
4. Add to every fetch headers block:
   ```js
   'x-api-key': API_KEY,
   'anthropic-version': '2023-06-01'
   ```

> **Never commit your API key to git.** Keep a `.env` file locally and reference it — or use Vercel environment variables (see Deploy section).

---

## Deploying to Vercel

### First deploy (CLI)
```bash
npm install -g vercel
cd /path/to/allie
vercel
# Follow prompts:
# Scope → takundazangas-projects
# Project name → allie
# Deploy → yes
```

### Subsequent deploys
```bash
vercel --prod
```

### Environment variables (keep key out of code)
Once deployed, go to Vercel dashboard → Allie project → Settings → Environment Variables:
```
ANTHROPIC_API_KEY = sk-ant-your-key-here
```
Then update the fetch call to read from `process.env.ANTHROPIC_API_KEY` — this requires moving to a small Node/Edge backend (next iteration).

### Drag and drop alternative
Vercel dashboard → Add New → Project → drag the `allie/` folder in.

---

## Iterating with Claude Code

This is the right workflow for all future changes to Allie.

### Setup
```bash
npm install -g @anthropic-ai/claude-code
cd /path/to/allie
claude
```

### How to give Claude Code instructions
Be specific about what to change and where. Examples:

```
"Make the sidebar 30px narrower and increase the feed font size to 0.9rem"

"Add a notes textarea to each skill card in the modal that saves to localStorage"

"Change Allie's tone in the system prompt — less formal, more like a late-night conversation"

"Add a new skill card under Liberation Studio: African Data Sovereignty, domain Liberation Studio · Ethics"

"Wire the context switcher so switching to LBLS changes the input placeholder to something poetry-specific"

"Add a keyboard shortcut — cmd+k — that clears the conversation and focuses the input"
```

### The iteration loop
```
Edit in Claude Code → refresh browser (cmd+R) → looks right → vercel --prod → live
```

Each loop takes about 60 seconds once you're set up.

### What Claude Code can see
It reads `index.html` directly and edits in place. Always tell it which section you're targeting — CSS, the system prompt, the skills data, the modal logic, etc. The file is structured with clear comments for each section.

---

## Architecture

### The system prompt (most important layer)
Located in the `<script>` block as `const ALLIE`. This is what makes Allie feel like a partner rather than a generic chatbot. It contains:

- Full project context (NurSara, Sasce, Liberation Studio, LBLS, THAW, A³I)
- Taku's communication style and preferences
- Mode-specific behaviour (THINK / WRITE / CHALLENGE / EDIT / BUILD)
- The ghost mentor framework for editorial work
- Tone guidance: warm peer, not challenger

**To update the system prompt in Claude Code:**
```
"Update the system prompt — NurSara just got its first paying customer, 
a Pflegeheim in Hamburg. Reflect this in the project status."
```

### Skills data
Located in `const SKILLS` array. Each skill has:
- `name`, `domain`, `type` — display metadata
- `desc` — card description
- `projects` — which ventures it connects to
- `p` — progress percentage (update manually as you learn)
- `c` — accent colour (matches the project's colour)
- `prompt` — the opening question Allie asks when you open the skill

**To add a new skill in Claude Code:**
```
"Add a new skill card: name='Notion API Integration', group='Ventures & Business',
domain='Allie · Technical', type='technical', desc='How to read and write Notion 
pages via API — authentication, page structure, database queries',
projects=['Allie'], progress=5, colour=#bf5c22,
prompt='Teach me Notion API integration for Allie — how to read and write pages, 
authenticate, and query databases so Allie can pull in live project context.'"
```

### Mode and context system
When mode or context changes mid-conversation, the thread resets and a banner appears. This is intentional — different registers need clean threads. The register reset lives in `setMode()` and `setCtx()`.

### Skills modal
Each skill opens a full conversation thread — ask follow-ups, go deep, request examples. The modal has its own `skillHistory` separate from the main conversation history so they don't bleed.

---

## Planned Next Iterations

These are the things that will make Allie genuinely better, in priority order:

**1. Persistent conversation memory**
Currently conversations reset on page refresh. Next step: use `localStorage` to persist the last N messages, so Allie remembers where you left off within a session.

**2. Notion API integration**
Connect to Notion so Allie can pull live project pages into context — NurSara status, LBLS manuscript notes, Liberation Studio engagement tracker. This requires a small backend (Vercel Edge Function) to proxy the Notion API securely.

**3. Skill progress persistence**
Progress bars are currently static. Wire them to localStorage so when you complete a Skills Lab session, the percentage updates and saves.

**4. PIE dot generator**
A dedicated mode or button that generates a daily dot in Taku's voice, in the correct PIE format, and optionally pushes it to a Notion page or THAW/PIE app.

**5. Voice input**
Web Speech API integration so you can talk to Allie the same way NurSara nurses talk to NurSara. Fitting.

**6. Claude Code project context**
Add a `CLAUDE.md` file (see below) so Claude Code always knows the architecture before touching anything.

---

## CLAUDE.md (for Claude Code)

When working on this project in Claude Code, always read this section first.

**What this file is:** A single HTML file containing a complete personal AI workspace. All CSS, JS, and HTML are in one file for simplicity. Do not split into multiple files unless explicitly asked.

**Key sections in index.html (in order):**
1. `<style>` — all CSS with CSS variables at the top in `:root`
2. HTML structure — topbar, sidebar, content area, modal
3. `<script>` — in this order:
   - `const ALLIE` — main system prompt (the most important thing)
   - `const SKILL_SYS` — skills teaching system prompt
   - `const SKILLS` — array of all skill cards
   - `const GROUPS` — render order for skill groups
   - `renderSkills()` — builds the skills grid
   - `switchView()`, `setMode()`, `setCtx()` — navigation
   - `freshStart()` — clears conversation
   - Chat functions — `addMsg()`, `addThinking()`, `sendMain()`
   - Skill modal functions — `openSkill()`, `kickSkill()`, `sendModal()`

**Design system:**
- Font: Lora (editorial/display) + DM Mono (metadata/labels) + DM Sans (body)
- Colour: amber/ember (#bf5c22, #d97840) as primary, warm dark background (#0d0b09)
- Grain texture overlay on body::after
- All colours as CSS variables — change in `:root` only

**Tone of Allie:** Warm peer. Version of Taku who's done the work. Not a coach, not a challenger. Pushes back gently, speaks plainly, never over-explains.

**When making changes:** Always make the minimum change that achieves the goal. Don't restructure unless asked. Don't change the system prompt tone unless explicitly directed.

---

## The Bigger Picture

Allie is also a proof of concept for Sasce.

The core architecture — a deeply personalised system prompt that makes an AI feel like it genuinely knows you, without storing personal data on a server — is exactly what Sasce needs. Every design decision here (context over storage, voice over data, minimum necessary intelligence) is a Sasce design decision.

What Allie teaches about building a personal AI layer will directly inform how Sasce holds user context safely, warmly, and in a way that feels like a friend's living room rather than a clinical intake form.

---

*Last updated: April 2026. Built with Claude. Deployed on Vercel.*
